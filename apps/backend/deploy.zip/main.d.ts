import { Express } from 'express';
export declare function getApp(): Promise<Express>;

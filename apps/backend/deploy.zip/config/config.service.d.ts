import { OnModuleInit } from '@nestjs/common';
export interface AppConfig {
    cosmosEndpoint: string;
    cosmosPrimaryKey: string;
    cosmosDatabase: string;
    cosmosContainer: string;
    storageConnectionString: string;
}
export declare class ConfigService implements OnModuleInit {
    private readonly logger;
    private config;
    onModuleInit(): Promise<void>;
    private loadConfig;
    private loadFromKeyVault;
    private loadFromEnv;
    get<K extends keyof AppConfig>(key: K): AppConfig[K];
}

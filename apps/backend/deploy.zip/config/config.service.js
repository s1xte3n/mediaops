"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var ConfigService_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.ConfigService = void 0;
const common_1 = require("@nestjs/common");
const keyvault_secrets_1 = require("@azure/keyvault-secrets");
const identity_1 = require("@azure/identity");
let ConfigService = ConfigService_1 = class ConfigService {
    constructor() {
        this.logger = new common_1.Logger(ConfigService_1.name);
        this.config = null;
    }
    async onModuleInit() {
        this.config = await this.loadConfig();
        this.logger.log('Configuration loaded');
    }
    async loadConfig() {
        const keyVaultUri = process.env.KEY_VAULT_URI;
        if (keyVaultUri) {
            this.logger.log(`Loading config from Key Vault: ${keyVaultUri}`);
            return this.loadFromKeyVault(keyVaultUri);
        }
        this.logger.log('Loading config from environment variables (local dev)');
        return this.loadFromEnv();
    }
    async loadFromKeyVault(vaultUri) {
        const credential = new identity_1.DefaultAzureCredential();
        const client = new keyvault_secrets_1.SecretClient(vaultUri, credential);
        const [cosmosEndpoint, cosmosPrimaryKey, storageConnectionString] = await Promise.all([
            client.getSecret('cosmos-endpoint').then((s) => s.value),
            client.getSecret('cosmos-primary-key').then((s) => s.value),
            client.getSecret('storage-connection-string').then((s) => s.value),
        ]);
        return {
            cosmosEndpoint,
            cosmosPrimaryKey,
            storageConnectionString,
            cosmosDatabase: process.env.COSMOS_DATABASE ?? 'mediaops',
            cosmosContainer: process.env.COSMOS_CONTAINER ?? 'MediaItems',
        };
    }
    loadFromEnv() {
        const required = [
            'COSMOS_ENDPOINT',
            'COSMOS_PRIMARY_KEY',
            'STORAGE_CONNECTION_STRING',
        ];
        for (const key of required) {
            if (!process.env[key]) {
                throw new Error(`Missing required environment variable: ${key}`);
            }
        }
        return {
            cosmosEndpoint: process.env.COSMOS_ENDPOINT,
            cosmosPrimaryKey: process.env.COSMOS_PRIMARY_KEY,
            storageConnectionString: process.env.STORAGE_CONNECTION_STRING,
            cosmosDatabase: process.env.COSMOS_DATABASE ?? 'mediaops',
            cosmosContainer: process.env.COSMOS_CONTAINER ?? 'MediaItems',
        };
    }
    get(key) {
        if (!this.config)
            throw new Error('Config not loaded yet');
        return this.config[key];
    }
};
exports.ConfigService = ConfigService;
exports.ConfigService = ConfigService = ConfigService_1 = __decorate([
    (0, common_1.Injectable)()
], ConfigService);
//# sourceMappingURL=config.service.js.map
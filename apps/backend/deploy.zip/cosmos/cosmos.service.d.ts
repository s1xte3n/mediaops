import { OnModuleInit } from '@nestjs/common';
import { Container } from '@azure/cosmos';
import { ConfigService } from '../config/config.service';
export declare class CosmosService implements OnModuleInit {
    private readonly config;
    private readonly logger;
    private container;
    constructor(config: ConfigService);
    onModuleInit(): Promise<void>;
    getContainer(): Container;
}

"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var CosmosService_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.CosmosService = void 0;
const common_1 = require("@nestjs/common");
const cosmos_1 = require("@azure/cosmos");
const config_service_1 = require("../config/config.service");
let CosmosService = CosmosService_1 = class CosmosService {
    constructor(config) {
        this.config = config;
        this.logger = new common_1.Logger(CosmosService_1.name);
    }
    async onModuleInit() {
        const client = new cosmos_1.CosmosClient({
            endpoint: this.config.get('cosmosEndpoint'),
            key: this.config.get('cosmosPrimaryKey'),
        });
        this.container = client
            .database(this.config.get('cosmosDatabase'))
            .container(this.config.get('cosmosContainer'));
        this.logger.log('Cosmos DB client initialized');
    }
    getContainer() {
        return this.container;
    }
};
exports.CosmosService = CosmosService;
exports.CosmosService = CosmosService = CosmosService_1 = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [config_service_1.ConfigService])
], CosmosService);
//# sourceMappingURL=cosmos.service.js.map
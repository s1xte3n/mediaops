export declare class CosmosModule {
}

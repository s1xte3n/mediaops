"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.getApp = getApp;
const core_1 = require("@nestjs/core");
const platform_express_1 = require("@nestjs/platform-express");
const common_1 = require("@nestjs/common");
const app_module_1 = require("./app.module");
const express = require("express");
let cachedApp = null;
async function getApp() {
    if (cachedApp)
        return cachedApp;
    const expressApp = express();
    const nestApp = await core_1.NestFactory.create(app_module_1.AppModule, new platform_express_1.ExpressAdapter(expressApp), { logger: ['error', 'warn', 'log'] });
    nestApp.setGlobalPrefix('api');
    nestApp.useGlobalPipes(new common_1.ValidationPipe({ whitelist: true }));
    await nestApp.init();
    cachedApp = expressApp;
    return cachedApp;
}
//# sourceMappingURL=main.js.map
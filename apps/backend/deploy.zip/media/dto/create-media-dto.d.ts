export declare class CreateMediaDto {
    filename: string;
    contentType: string;
}

import { MediaService } from './media.service';
import { CreateMediaDto } from './dto/create-media-dto';
export declare class MediaController {
    private readonly media;
    constructor(media: MediaService);
    create(dto: CreateMediaDto, headers: Record<string, string>): Promise<{
        id: string;
        status: import("./media.types").MediaStatus;
        rawBlobPath: string;
        upload: {
            method: string;
            url: string;
            contentType: string;
            maxBytes: number;
        };
    }>;
    uploadContent(id: string, headers: Record<string, string>, file: Express.Multer.File): Promise<{
        id: string;
        status: import("./media.types").MediaStatus;
        rawBlobPath: string;
    }>;
    list(headers: Record<string, string>, limit?: string, cursor?: string): Promise<{
        items: import("./media.types").MediaItem[];
        nextCursor: string | null;
    }>;
    findOne(id: string, headers: Record<string, string>): Promise<import("./media.types").MediaItem>;
}

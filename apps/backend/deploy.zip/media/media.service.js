"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var MediaService_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.MediaService = void 0;
const common_1 = require("@nestjs/common");
const cosmos_service_1 = require("../cosmos/cosmos.service");
const storage_service_1 = require("../storage/storage.service");
const uuid_1 = require("uuid");
const MAX_BYTES = 10 * 1024 * 1024;
const ALLOWED_TYPES = [
    'image/png',
    'image/jpeg',
    'image/gif',
    'image/webp',
    'application/json'
];
let MediaService = MediaService_1 = class MediaService {
    constructor(cosmos, storage) {
        this.cosmos = cosmos;
        this.storage = storage;
        this.logger = new common_1.Logger(MediaService_1.name);
    }
    async create(dto, ownerId) {
        const id = (0, uuid_1.v4)();
        const now = new Date().toISOString();
        const item = {
            id,
            ownerId,
            filename: dto.filename,
            contentType: dto.contentType,
            rawBlobPath: null,
            thumbBlobPath: null,
            status: 'Created',
            tags: [],
            sha256: null,
            createdAt: now,
            processedAt: null,
            error: null,
            attempt: 0,
        };
        await this.cosmos.getContainer().items.create(item);
        this.logger.log({ message: 'Media item created', mediaId: id, ownerId });
        return item;
    }
    async uploadContent(id, ownerId, file) {
        const item = await this.findById(id, ownerId);
        if (item.status !== 'Created') {
            throw new common_1.ConflictException(`Item is already in status ${item.status}. Cannot re-upload.`);
        }
        if (file.size > MAX_BYTES) {
            throw new common_1.PayloadTooLargeException(`File exceeds maximum size of ${MAX_BYTES} bytes`);
        }
        if (!ALLOWED_TYPES.includes(file.mimetype)) {
            throw new common_1.ConflictException(`Unsupported content type: ${file.mimetype}`);
        }
        const blobPath = `raw/${ownerId}/${id}/${file.originalname}`;
        await this.storage.uploadBuffer('raw', blobPath, file.buffer, file.mimetype);
        const now = new Date().toISOString();
        const updated = {
            ...item,
            status: 'Uploaded',
            rawBlobPath: blobPath,
            createdAt: item.createdAt ?? now,
        };
        await this.cosmos.getContainer().items.upsert(updated);
        this.logger.log({
            message: 'Media content uploaded',
            mediaId: id,
            ownerId,
            blobPath,
        });
        return updated;
    }
    async findById(id, ownerId) {
        const { resource } = await this.cosmos
            .getContainer()
            .item(id, ownerId)
            .read();
        if (!resource) {
            throw new common_1.NotFoundException(`Media item ${id} not found`);
        }
        return resource;
    }
    async list(ownerId, limit = 20, continuation) {
        const querySpec = {
            query: 'SELECT * FROM c WHERE c.ownerId = @ownerId ORDER BY c.createdAt DESC OFFSET 0 LIMIT @limit',
            parameters: [
                { name: '@ownerId', value: ownerId },
                { name: '@limit', value: limit },
            ],
        };
        const response = await this.cosmos
            .getContainer()
            .items.query(querySpec, {
            maxItemCount: limit,
            continuationToken: continuation,
        })
            .fetchNext();
        return {
            items: response.resources,
            nextCursor: response.continuationToken ?? null,
        };
    }
};
exports.MediaService = MediaService;
exports.MediaService = MediaService = MediaService_1 = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [cosmos_service_1.CosmosService,
        storage_service_1.StorageService])
], MediaService);
//# sourceMappingURL=media.service.js.map
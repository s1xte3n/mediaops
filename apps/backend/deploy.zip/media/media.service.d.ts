import { CosmosService } from '../cosmos/cosmos.service';
import { StorageService } from 'src/storage/storage.service';
import { CreateMediaDto } from './dto/create-media-dto';
import { MediaItem } from './media.types';
export declare class MediaService {
    private readonly cosmos;
    private readonly storage;
    private readonly logger;
    constructor(cosmos: CosmosService, storage: StorageService);
    create(dto: CreateMediaDto, ownerId: string): Promise<MediaItem>;
    uploadContent(id: string, ownerId: string, file: Express.Multer.File): Promise<MediaItem>;
    findById(id: string, ownerId: string): Promise<MediaItem>;
    list(ownerId: string, limit?: number, continuation?: string): Promise<{
        items: MediaItem[];
        nextCursor: string | null;
    }>;
}

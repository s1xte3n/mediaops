"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.MediaController = void 0;
const common_1 = require("@nestjs/common");
const platform_express_1 = require("@nestjs/platform-express");
const multer_1 = require("multer");
const media_service_1 = require("./media.service");
const create_media_dto_1 = require("./dto/create-media-dto");
function getOwnerIdFromHeaders(headers) {
    const devOwner = headers['x-dev-owner-id'];
    if (devOwner)
        return devOwner;
    const principal = headers['x-ms-client-principal'];
    if (principal) {
        const decoded = JSON.parse(Buffer.from(principal, 'base64').toString('utf8'));
        return decoded.userId ?? decoded.objectidentifier ?? 'annonymous';
    }
    return 'annonymous';
}
let MediaController = class MediaController {
    constructor(media) {
        this.media = media;
    }
    async create(dto, headers) {
        const ownerId = getOwnerIdFromHeaders(headers);
        const item = await this.media.create(dto, ownerId);
        return {
            id: item.id,
            status: item.status,
            rawBlobPath: item.rawBlobPath,
            upload: {
                method: 'PUT',
                url: `/api/media/${item.id}/content`,
                contentType: item.contentType,
                maxBytes: 10 * 1024 * 1024
            },
        };
    }
    async uploadContent(id, headers, file) {
        if (!file) {
            throw new common_1.BadRequestException('No file provided in field "file"');
        }
        const ownerId = getOwnerIdFromHeaders(headers);
        const item = await this.media.uploadContent(id, ownerId, file);
        return {
            id: item.id,
            status: item.status,
            rawBlobPath: item.rawBlobPath,
        };
    }
    async list(headers, limit, cursor) {
        const ownerId = getOwnerIdFromHeaders(headers);
        return this.media.list(ownerId, limit ? parseInt(limit) : 20, cursor);
    }
    async findOne(id, headers) {
        const ownerId = getOwnerIdFromHeaders(headers);
        return this.media.findById(id, ownerId);
    }
};
exports.MediaController = MediaController;
__decorate([
    (0, common_1.Post)(),
    (0, common_1.HttpCode)(common_1.HttpStatus.CREATED),
    __param(0, (0, common_1.Body)()),
    __param(1, (0, common_1.Headers)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [create_media_dto_1.CreateMediaDto, Object]),
    __metadata("design:returntype", Promise)
], MediaController.prototype, "create", null);
__decorate([
    (0, common_1.Put)(':id/content'),
    (0, common_1.UseInterceptors)((0, platform_express_1.FileInterceptor)('file', { storage: (0, multer_1.memoryStorage)() })),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Headers)()),
    __param(2, (0, common_1.UploadedFile)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object, Object]),
    __metadata("design:returntype", Promise)
], MediaController.prototype, "uploadContent", null);
__decorate([
    (0, common_1.Get)(),
    __param(0, (0, common_1.Headers)()),
    __param(1, (0, common_1.Query)('limit')),
    __param(2, (0, common_1.Query)('cursor')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, String, String]),
    __metadata("design:returntype", Promise)
], MediaController.prototype, "list", null);
__decorate([
    (0, common_1.Get)(':id'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Headers)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", Promise)
], MediaController.prototype, "findOne", null);
exports.MediaController = MediaController = __decorate([
    (0, common_1.Controller)('media'),
    __metadata("design:paramtypes", [media_service_1.MediaService])
], MediaController);
//# sourceMappingURL=media.controller.js.map
"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
var EventBridgeController_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.EventBridgeController = void 0;
const common_1 = require("@nestjs/common");
const eventbridge_service_1 = require("./eventbridge.service");
const uuid_1 = require("uuid");
let EventBridgeController = EventBridgeController_1 = class EventBridgeController {
    constructor(eventBridge) {
        this.eventBridge = eventBridge;
        this.logger = new common_1.Logger(EventBridgeController_1.name);
    }
    async handleBlobEvent(eventType, body) {
        if (eventType === 'SubscriptionValidation') {
            const validationBody = body;
            this.logger.log('Event Grid subscription validation handshake');
            return { validationResponse: validationBody.validationCode };
        }
        const events = body;
        for (const event of events) {
            if (event.eventType !== 'Microsoft.Storage.BlobCreated') {
                this.logger.log(`Skipping event type: ${event.eventType}`);
                continue;
            }
            const blobUrl = event.data?.url;
            if (!blobUrl) {
                this.logger.warn('BlobCreated event missing url in data');
                continue;
            }
            const parsed = this.eventBridge.parseBlobPath(blobUrl);
            if (!parsed) {
                this.logger.warn(`Could not parse blob path from URL: ${blobUrl}`);
                continue;
            }
            const message = {
                v: 1,
                correlationId: (0, uuid_1.v4)(),
                mediaId: parsed.mediaId,
                ownerId: parsed.ownerId,
                rawBlobPath: parsed.rawBlobPath,
                contentType: event.data.contentType ?? 'application/octet-stream',
                enqueuedAt: new Date().toISOString(),
                attempt: 1,
            };
            await this.eventBridge.enqueue(message);
        }
        return { received: true };
    }
};
exports.EventBridgeController = EventBridgeController;
__decorate([
    (0, common_1.Post)('blob'),
    (0, common_1.HttpCode)(common_1.HttpStatus.OK),
    __param(0, (0, common_1.Headers)('aeg-event-type')),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", Promise)
], EventBridgeController.prototype, "handleBlobEvent", null);
exports.EventBridgeController = EventBridgeController = EventBridgeController_1 = __decorate([
    (0, common_1.Controller)('eventbridge'),
    __metadata("design:paramtypes", [eventbridge_service_1.EventBridgeService])
], EventBridgeController);
//# sourceMappingURL=eventbridge.controller.js.map
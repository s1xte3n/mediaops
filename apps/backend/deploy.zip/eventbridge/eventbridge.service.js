"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var EventBridgeService_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.EventBridgeService = void 0;
const common_1 = require("@nestjs/common");
const storage_queue_1 = require("@azure/storage-queue");
const config_service_1 = require("../config/config.service");
let EventBridgeService = EventBridgeService_1 = class EventBridgeService {
    constructor(config) {
        this.config = config;
        this.logger = new common_1.Logger(EventBridgeService_1.name);
    }
    onModuleInit() {
        this.queueClient = storage_queue_1.QueueServiceClient.fromConnectionString(this.config.get('storageConnectionString'));
        this.logger.log('Queue client initialized');
    }
    async enqueue(message) {
        const queue = this.queueClient.getQueueClient('process-queue');
        const encoded = Buffer.from(JSON.stringify(message)).toString('base64');
        await queue.sendMessage(encoded);
        this.logger.log({
            message: 'Enqueued procesing message',
            mediaId: message.mediaId,
            correlationId: message.correlationId,
        });
    }
    parseBlobPath(blobUrl) {
        try {
            const url = new URL(blobUrl);
            const parts = url.pathname.split('/').filter(Boolean);
            if (parts.length < 4 || parts[0] !== 'raw')
                return null;
            return {
                ownerId: parts[1],
                mediaId: parts[2],
                filename: parts[3],
                rawBlobPath: parts.slice(0).join('/')
            };
        }
        catch {
            return null;
        }
    }
};
exports.EventBridgeService = EventBridgeService;
exports.EventBridgeService = EventBridgeService = EventBridgeService_1 = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [config_service_1.ConfigService])
], EventBridgeService);
//# sourceMappingURL=eventbridge.service.js.map
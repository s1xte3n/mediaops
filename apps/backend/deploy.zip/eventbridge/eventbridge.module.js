"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.EventBridgeModule = void 0;
const common_1 = require("@nestjs/common");
const eventbridge_controller_1 = require("./eventbridge.controller");
const eventbridge_service_1 = require("./eventbridge.service");
let EventBridgeModule = class EventBridgeModule {
};
exports.EventBridgeModule = EventBridgeModule;
exports.EventBridgeModule = EventBridgeModule = __decorate([
    (0, common_1.Module)({
        controllers: [eventbridge_controller_1.EventBridgeController],
        providers: [eventbridge_service_1.EventBridgeService],
    })
], EventBridgeModule);
//# sourceMappingURL=eventbridge.module.js.map
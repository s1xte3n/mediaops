export declare class EventBridgeModule {
}

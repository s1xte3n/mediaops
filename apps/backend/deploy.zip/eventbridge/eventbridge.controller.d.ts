import { EventBridgeService } from './eventbridge.service';
interface EventGridEvent {
    id: string;
    eventType: string;
    subject: string;
    data: {
        url?: string;
        contentType?: string;
    };
    dataVersion: string;
    metadataVersion: string;
    eventTime: string;
    topic: string;
}
export declare class EventBridgeController {
    private readonly eventBridge;
    private readonly logger;
    constructor(eventBridge: EventBridgeService);
    handleBlobEvent(eventType: string, body: EventGridEvent[] | {
        validationCode: string;
    }): Promise<{
        validationResponse: string;
        received?: undefined;
    } | {
        received: boolean;
        validationResponse?: undefined;
    }>;
}
export {};

import { ConfigService } from '../config/config.service';
export interface QueueMessage {
    v: number;
    correlationId: string;
    mediaId: string;
    ownerId: string;
    rawBlobPath: string;
    contentType: string;
    enqueuedAt: string;
    attempt: number;
}
export declare class EventBridgeService {
    private readonly config;
    private readonly logger;
    private queueClient;
    constructor(config: ConfigService);
    onModuleInit(): void;
    enqueue(message: QueueMessage): Promise<void>;
    parseBlobPath(blobUrl: string): {
        ownerId: string;
        mediaId: string;
        filename: string;
        rawBlobPath: string;
    } | null;
}

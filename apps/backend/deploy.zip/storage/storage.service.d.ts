import { OnModuleInit } from '@nestjs/common';
import { BlockBlobClient } from '@azure/storage-blob';
import { ConfigService } from '../config/config.service';
export declare class StorageService implements OnModuleInit {
    private readonly config;
    private readonly logger;
    private blobServiceClient;
    constructor(config: ConfigService);
    onModuleInit(): Promise<void>;
    getBlobClient(container: string, blobPath: string): BlockBlobClient;
    uploadBuffer(container: string, blobPath: string, buffer: Buffer, contextType: string): Promise<string>;
}

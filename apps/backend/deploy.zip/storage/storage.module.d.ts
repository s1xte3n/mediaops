export declare class StorageModule {
}

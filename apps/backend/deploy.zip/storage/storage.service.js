"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var StorageService_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.StorageService = void 0;
const common_1 = require("@nestjs/common");
const storage_blob_1 = require("@azure/storage-blob");
const config_service_1 = require("../config/config.service");
let StorageService = StorageService_1 = class StorageService {
    constructor(config) {
        this.config = config;
        this.logger = new common_1.Logger(StorageService_1.name);
    }
    async onModuleInit() {
        this.blobServiceClient = storage_blob_1.BlobServiceClient.fromConnectionString(this.config.get('storageConnectionString'));
        this.logger.log('Blob Storage client initialized');
    }
    getBlobClient(container, blobPath) {
        return this.blobServiceClient
            .getContainerClient(container)
            .getBlockBlobClient(blobPath);
    }
    async uploadBuffer(container, blobPath, buffer, contextType) {
        const client = this.getBlobClient(container, blobPath);
        await client.uploadData(buffer, {
            blobHTTPHeaders: { blobContentType: contextType },
        });
        this.logger.log({ message: 'Blob uploaded', container, blobPath });
        return blobPath;
    }
};
exports.StorageService = StorageService;
exports.StorageService = StorageService = StorageService_1 = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [config_service_1.ConfigService])
], StorageService);
//# sourceMappingURL=storage.service.js.map
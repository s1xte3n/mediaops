"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const functions_1 = require("@azure/functions");
const main_1 = require("../../main");
const http = require("http");
functions_1.app.http('nestjs', {
    methods: ['GET', 'POST', 'PUT', 'PATCH', 'DELETE', 'HEAD', 'OPTIONS'],
    authLevel: 'anonymous',
    route: '{*segments}',
    handler: async (req, context) => {
        const expressApp = await (0, main_1.getApp)();
        return new Promise((resolve) => {
            const url = new URL(req.url);
            const mockReq = Object.assign(new http.IncomingMessage(null), {
                method: req.method,
                url: url.pathname + url.search,
                headers: Object.fromEntries(req.headers.entries()),
            });
            const mockRes = new http.ServerResponse(mockReq);
            const chunks = [];
            mockRes.write = (chunk) => {
                chunks.push(Buffer.isBuffer(chunk) ? chunk : Buffer.from(chunk));
                return true;
            };
            mockRes.end = (chunk) => {
                if (chunk)
                    chunks.push(Buffer.isBuffer(chunk) ? chunk : Buffer.from(chunk));
                const headers = {};
                const rawHeaders = mockRes.getHeaders();
                for (const [key, value] of Object.entries(rawHeaders)) {
                    if (value !== undefined)
                        headers[key] = String(value);
                }
                resolve({
                    status: mockRes.statusCode,
                    headers,
                    body: Buffer.concat(chunks),
                });
                return mockRes;
            };
            req.arrayBuffer().then((buffer) => {
                if (buffer.byteLength > 0) {
                    mockReq.push(Buffer.from(buffer));
                }
                mockReq.push(null);
                expressApp(mockReq, mockRes);
            });
        });
    }
});
//# sourceMappingURL=index.js.map